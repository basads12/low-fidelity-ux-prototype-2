# De Kunst van Kunst — Design Foundation v1.0

**Bouwbasis voor:** website · chequeherkenning · planner · bevestiging
**Stack:** React 18 · Tailwind v4 · shadcn/ui · Vite (huidige projectopstelling)
**Bron-hiërarchie:** Positionerings-DNA V4.1 → Fact Sheet V1.1 → Message Rules V1.1 → Blueprint V1.1

---

## 1. Wat dit document is

Dit is de styling-foundation, géén pagina-build. Lees `theme.css` (de tokens) en
`foundation-preview.html` (de visuele showcase met alle componenten in context)
samen — de preview toont wat de tokens opleveren.

**Wat hier vastligt:**
kleurpalet · typografie · spacing · radius · shadows · 12 componenten ·
beeldrichtlijnen · do's & don'ts.

**Wat hier nog niet ligt:**
volledige pagina's, copy, finale fotografie, animaties met scroll, admin-UI.

---

## 2. Installatie in de bestaande bouw

Het huidige `theme.css` is het default-shadcn-thema (paars-zwart, neutraal-grijs).
Vervang dat bestand met de nieuwe `theme.css` uit deze foundation:

1. Vervang `src/styles/theme.css` door `dkvk-foundation/theme.css`.
2. Voeg in `index.html` (of waar `<head>` wordt gebouwd) toe:
   ```html
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
   ```
   Of zelfgehost via `fonts.css` indien de Variable-versies lokaal liggen.
3. Geen wijzigingen in `package.json` of `vite.config.ts` nodig — Tailwind v4 leest
   de nieuwe `@theme inline` block automatisch.
4. Doorloop de huidige componenten en vervang oude utility-classes:
   - `bg-gray-900 text-white` → `bg-primary text-primary-foreground`
   - `bg-gray-100` → `bg-card-soft` of `bg-muted`
   - `border-gray-300` → `border-border` of `border-border-strong`
   - `text-gray-700` → `text-ink-700` of standaard body-default

De QA-blokken (rode banners) in de huidige bouw blijven functioneel-rood en
horen niet bij het publieke palet — die mogen voorlopig zo blijven, ze zijn
internal-only.

---

## 3. Tokens — snelle referentie

### Kleuren (semantisch — gebruik deze in componenten)

| Token | Hex | Gebruik |
|---|---|---|
| `--background` | `#fbf8f3` (stone-50) | page background — nooit hard wit |
| `--card` | `#ffffff` | losstaande cards die uit het papier omhoog komen |
| `--card-soft` | `#f5efe6` (stone-100) | rustige sub-cards, helpblokken |
| `--foreground` | `#1c1a16` (ink-900) | primaire tekst |
| `--primary` | `#7d3833` (bordeaux-600) | CTA, focus-ring, merksignalen |
| `--accent` | `#c89a47` (oker-400) | eyebrows, hairlines, cheque-detail |
| `--accent-soft` | `#f4e8cf` (oker-100) | uiterst spaarzaam, alleen op cheque-card |
| `--border` | `#e1d5c2` (stone-200) | standaard scheidingslijn |
| `--ring` | `bordeaux-600` | focus-state op alle interactieve elementen |
| `--destructive` | `#8b3a2e` | foutmelding-tekst en rand |

**Niet gebruiken:** zuiver zwart, zuiver wit (behalve op `--card`), groen voor
"goed nieuws", blauw voor "info", oranje of geel als vlak.

### Radius

| Token | Pixels | Toepassing |
|---|---|---|
| `--radius-sm` | 4px | tags, pills, kleine elementen |
| `--radius-md` | 6px | buttons, inputs |
| `--radius-lg` | 8px | cards |
| `--radius-xl` | 12px | hero-card, cheque-card |

Bewust kleiner dan default shadcn (10px) — voelt ambachtelijker en feitelijker,
minder app-achtig.

### Schaduwen

Warm getint (bordeaux-tint, niet pure black):

| Token | Toepassing |
|---|---|
| `--shadow-xs` | primary button rust-state |
| `--shadow-sm` | standaard card |
| `--shadow-md` | hero-card, persoonlijk welkomstscherm |
| `--shadow-lg` | popover, dropdown, modal |
| `--shadow-cheque` | uitsluitend de cheque-card |
| `--shadow-focus` | focus-ring (3px bordeaux op 18% alpha) |

### Typografie

Eén familie: **Inter Tight** (Variable, gewichten 400/500/600).
Mono: **JetBrains Mono** (alleen voor chequenummer, technische data).

| Element | Maat | Gewicht | Tracking | Line-height |
|---|---|---|---|---|
| H1 | 42 / 52px | 500 | -0.022em | 1.1 |
| H2 | 34px | 500 | -0.022em | 1.15 |
| H3 | 28px | 500 | -0.022em | 1.3 |
| H4 | 22px | 500 | normal | 1.3 |
| Lead | 18px | 400 | normal | 1.7 |
| Body | 16px | 400 | -0.005em | 1.55 |
| Label | 15px | 500 | normal | 1.3 |
| Eyebrow | 13px | 500 | 0.14em UPPER | 1.3 |
| Meta | 13px | 400 | normal | 1.5 |

### Spacing

| Token | Pixels | Toepassing |
|---|---|---|
| `--space-section-y-mobile` | 56px | tussen secties op mobiel |
| `--space-section-y-desktop` | 96px | tussen secties op desktop |
| `--space-block-y` | 32px | tussen blokken binnen sectie |
| `--space-card-padding` | 24px | standaard card |
| `--space-card-padding-lg` | 32px | hero-card, cheque-card |
| `--space-stack-tight` | 8px | binnen labels |
| `--space-stack` | 16px | default tussen elementen |
| `--space-stack-loose` | 24px | vóór CTA |

### Containers

| Token | Pixels | Toepassing |
|---|---|---|
| `--container-sm` | 576px | content-blokken, formulieren |
| `--container-md` | 672px | hero, welkomstscherm, planner |
| `--container-lg` | 896px | algemene pagina-content |
| `--container-xl` | 1152px | admin-dashboard |

---

## 4. Component-utility patronen

### Primary button
```tsx
<button className="
  inline-flex items-center justify-center gap-2
  px-6 py-3.5
  bg-primary text-primary-foreground
  rounded-md
  font-medium leading-none
  shadow-xs
  transition-colors
  hover:bg-bordeaux-500
  active:bg-bordeaux-700
  focus-visible:outline-none focus-visible:ring-[3px] focus-visible:ring-bordeaux-600/[0.18]
  disabled:opacity-50 disabled:cursor-not-allowed
">
  Activeer uw cheque
</button>
```

### Secondary button (outline)
```tsx
<button className="
  inline-flex items-center justify-center
  px-6 py-3.5
  bg-transparent text-ink-800
  border border-border-strong rounded-md
  font-medium
  transition-colors
  hover:bg-card-soft hover:border-ink-700
">
  Meer over de galerie
</button>
```

### Tekst-button (laagste hiërarchie)
```tsx
<button className="
  px-1 py-2
  text-ink-800 underline decoration-stone-300 underline-offset-4
  hover:text-bordeaux-600 hover:decoration-bordeaux-600
">
  Plan uw bezoek
</button>
```

### Standaard card
```tsx
<article className="
  bg-card border border-border rounded-lg
  p-6 md:p-8
  shadow-sm
">
```

### Hero / welkomstscherm card
```tsx
<article className="
  bg-card border border-border rounded-xl
  p-8 md:p-10
  shadow-md
  max-w-[36rem] mx-auto
">
```

### Cheque-card (kern: bordeaux-strook links + oker-cirkel rechtsboven)
Zie de markup in `foundation-preview.html` § 06 — pseudo-elementen `::before`
voor de strook en `::after` voor de cirkel houden de markup schoon.

### Form input
```tsx
<input className="
  w-full px-4 py-3.5
  bg-input-background
  border border-input-border rounded-md
  text-ink-900 placeholder:text-ink-400
  transition-colors
  hover:border-ink-500
  focus:outline-none focus:border-primary focus:ring-[3px] focus:ring-bordeaux-600/[0.18]
" />
```

### Slot (planner — datum / tijd)
Drie states: default · `--selected` (bordeaux-vlak) · `--unavailable`
(line-through, gedimd). Zie `.slot` in de preview.

### Day-card met dag-extra's (planner stap 1)

Eén kaart per beschikbare dag. **Iedere dag krijgt exact dezelfde visuele
behandeling** — alleen de inhoud van de extra-lijst verschilt. Dit voorkomt
dat één dag visueel "beter" oogt dan een andere.

```tsx
<button type="button" className="
  block w-full text-left
  bg-card border border-border rounded-lg
  p-5
  transition-colors
  hover:border-ink-500
  data-[selected=true]:border-primary
  data-[selected=true]:bg-bordeaux-50
  data-[selected=true]:ring-1 data-[selected=true]:ring-bordeaux-600
">
  <div className="flex items-baseline justify-between mb-3.5">
    <span className="text-[13px] font-medium uppercase tracking-[0.14em] text-ink-700">Maandag</span>
    <span className="text-sm text-ink-500">4 mei 2026</span>
  </div>
  <p className="text-[13px] text-ink-500 mb-2">Bij uw bezoek op deze dag inbegrepen:</p>
  <ul className="space-y-1">
    <li className="relative pl-5 text-[15px] text-ink-800
                   before:absolute before:left-0 before:top-[14px]
                   before:w-2.5 before:h-px before:bg-bordeaux-300">
      Autowasbeurt bij [partnernaam]
    </li>
    <li className="...">Wellness bij [partnernaam]</li>
    <li className="...">Kleine attentie in de galerie</li>
  </ul>
</button>
```

**Bullets zijn een stille bordeaux streepje, géén cadeau-icoon.** Bron-regel:
geen cadeau-iconen als voordeelindicator, geen "+ N inbegrepen" naast de
dagnaam, geen partnerlogo's bij de extra.

### Compacte inbegrepen-samenvatting (planner stap 2 + bevestiging)

Op stap 2 (tijdkeuze) en stap 4 (controle) wordt de extra-lijst in compacte
proza-vorm herhaald als context. Op het afspraak-bevestigd-scherm wordt de
volledige lijst herhaald.

```tsx
<div className="bg-card-soft border border-border rounded-md p-4">
  <p className="text-xs font-medium uppercase tracking-[0.14em] text-ink-500 mb-2">
    Bij uw bezoek op deze dag inbegrepen
  </p>
  <p className="text-[15px] text-ink-700 leading-relaxed">
    Autowasbeurt bij [partnernaam], Wellness bij [partnernaam], Kleine attentie in de galerie.
  </p>
  <p className="text-[13px] text-ink-500 mt-2.5">
    De praktische gegevens bij deze onderdelen staan in uw bevestiging.
  </p>
</div>
```

---

## 5. Beeldrichtlijnen

**Wel**
- Echte galeriebeelden in context (werk aan wand, detail handgeschilderd, certificaat).
- Lage tot middel saturatie. Geen extreme HDR.
- Verticale stack op mobiel; 3-koloms grid op desktop.
- Tot fotografie definitief: low-fidelity placeholder met diagonaal patroon (zie preview).

**Niet**
- Stockfotografie, "dame-met-schilderij", "tevreden stelletje".
- Productfoto's op witte achtergrond.
- Catalogusraster of webshop-grid als hoofdstructuur.
- GIF, autoplay-video, videohero.
- AI-gegenereerde galerie-impressies.
- Modellen, gezichten in close-up.

---

## 6. Toegestane CTA-teksten

```
Activeer uw cheque
Plan uw bezoek
Kies uw bezoekmoment
Maak een afspraak
Cheque overdragen
Meer over de galerie     (alleen secundair op homepage)
```

**Niet gebruiken:**
Claim · Profiteer · Boek uw middag · Ontdek · Shop · Gratis · Korting ·
Reserveer · Verzilver · Activeer uw account · Bekijk ook · Volg ons.

---

## 7. Verificatie-checklist per scherm

Vóór een scherm in productie gaat, loop deze lijst af:

- [ ] Eén primaire bordeaux-CTA — niet meer.
- [ ] Géén `bg-gray-900` of `bg-black` op CTA's of vlakken.
- [ ] Géén € 500, percentages, of voordeelclaims.
- [ ] Géén partnerlogo's anders dan individueel op het cheque-card.
- [ ] Géén urgency-elementen (timer, "nog X plekken").
- [ ] Géén autoplay, GIF, videohero.
- [ ] Géén pop-up, exit-intent, nieuwsbrief-opt-in.
- [ ] Géén sterren of reviewscore.
- [ ] Mobiele 1-koloms, geen catalogusraster.
- [ ] Eyebrow (oker, uppercase) max 1× per scherm.
- [ ] Bij persoonlijke route: geen herhaalde chequenummer-input.
- [ ] Tekst van CTA staat in de toegelaten lijst.

**Extra checks voor planner stap 1 (dag-keuze) en bevestigingsscherm:**

- [ ] Iedere dag krijgt visueel dezelfde behandeling — geen rangorde-suggestie.
- [ ] Géén cadeau-iconen of telnummers (🎁 ×3) bij de dagnaam.
- [ ] Géén bedragen ("€ 97,50", "t.w.v.") bij extra's.
- [ ] Géén "Mystery Gift" of "Verrassingsgeschenk" — gebruik "Kleine attentie in de galerie".
- [ ] Géén "Belevingspakket", "Arrangement", "Executive-pakket".
- [ ] Géén "Reserveer maandag" als CTA per dag — de planner-CTA blijft "Verder" / "Kies uw bezoekmoment".
- [ ] Géén checkbox of toggle om extra's bij te kopen of weg te kiezen.
- [ ] Géén partnerlogo bij de extra — alleen partnernaam in tekst.
- [ ] Bij ontbrekende partnernaam: `[partnernaam]`-placeholder + intern QA-label.
- [ ] Stap 4 en afspraak-bevestigd-scherm tonen extras-lijst.
- [ ] Lange beschrijvingen ("3 uur toegang", "Blob Protection") staan niet in de planner — alleen in de bevestigingsmail als praktisch detailblok.

---

## 8. Rationale per kernkeuze (kort)

**Bordeaux ipv zwart als CTA.** Een zwarte CTA op licht-warm papier voelt
als webshop-conversieknop. Bordeaux verbindt de actie aan het merk en past
in het kunstgeschiedenis-register.

**Stone-50 ipv wit als page-background.** Pure wit is het achtergrond-DNA
van Bol, Coolblue, Amazon. Stone-50 is papier — de drager waarop de klant
rustig kan lezen.

**Inter Tight ipv Inter / Helvetica / Playfair.** Inter Tight heeft van
zichzelf nauwere tracking, wat in koppen rust geeft. Helvetica is ongelovig,
Playfair activeert mode/bruiloft. Eén familie houdt de pagina hiërarchisch op
spatie en gewicht, wat past bij "feitelijk en concreet".

**Radius 6/8/12px ipv 10/16/24.** Sterkere afronding voelt mobile-app /
SaaS. Subtielere afronding voelt ambachtelijk en hoort bij het papier-DNA.

**Warm getinte schaduwen ipv pure black.** Pure-zwart shadows op een
warm-licht palet voelen "uitgesneden", e-commercey. Bordeaux-tint integreert
de elevatie met het palet.

**Cheque-card met bordeaux-strook + oker-cirkel.** Dit is de enige
component die direct merk-symboliek draagt. De strook is functioneel anker
voor de hiërarchie, de cirkel imiteert de zegel-detail van de papieren cheque.
Géén € 500, géén streepjescode, géén "Voucher" — dat zou de cheque tot
waardebon degraderen.

**Inline error met warm bruin-rood.** Klassieke alarm-rood (#ff0000) trekt
te veel aandacht en voelt als systeemfalen. Bruin-rood is feitelijk: "dit
klopt niet" zonder de klant het gevoel te geven dat hij iets verkeerd heeft
gedaan.

**Dag-extra's gelijkwaardig per dag, geen iconen, geen bedragen.**
Cadeau-iconen die op maandag drie keer voorkomen en op zaterdag één keer
creëren een impliciete rangorde — maandag oogt dan "beter" dan zaterdag,
zelfs zonder bedragen. Dat is precies het voordeel-frame dat het DNA
uitsluit. De inhoud van de extra's verschilt per dag, de visuele
behandeling niet: zelfde formaat kaart, zelfde label "Bij uw bezoek op
deze dag inbegrepen:", zelfde bullet-stijl. Het bullet-streepje is een
stille bordeaux hairline, niet een 🎁-icoon. Partnernamen staan in tekst
("Wellness bij [partnernaam]"), niet als logo.

---

## 9. Wat hierna komt (volgende fases, niet in deze foundation)

1. **Component-implementatie** — vertaal de huidige `.tsx`-componenten
   (Homepage, ChequeInput, PlannerDay, etc.) naar de nieuwe tokens.
2. **Beeldproductie** — fotograferen van galerie, detail werk, certificaat.
   Tot dan low-fi placeholders.
3. **Animatie-ritme** — subtiele scroll-fade-in per sectie, géén staggers
   of bounce. Maximum: 220ms ease-out, één property per beweging.
4. **Admin/dashboard-skin** — dark mode is voorbereid in `theme.css` voor
   intern gebruik (galerie-medewerkers).
5. **Accessibility audit** — alle kleurcombinaties tegen WCAG AA toetsen
   (bordeaux-600 op stone-50 zit ruim boven 4.5:1; oker-400 nooit als
   foreground op stone-50 gebruiken — alleen als rand of boven 24px).
6. **Print-stylesheet voor de bevestigingspagina** — klant kan afspraak
   meenemen op papier.

---

*Bij conflict tussen deze foundation en het Positionerings-DNA V4.1 is
V4.1 leidend. Foundation-wijzigingen vereisen review tegen V4.1 en
Message Rules V1.1.*
